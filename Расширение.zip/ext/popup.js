chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
    var activeTab = tabs[0];
    var url = activeTab.url;
    chrome.runtime.sendMessage({action: 'getScore', url: url}, function(response) {
        if (response) {
            document.getElementById('result').innerText = 'S-рейтинг: ' + response.score;
            document.getElementById('dom').innerText = 'domain: ' + response.domain;
        } else {
            document.getElementById('result').innerText = 'Error fetching score';
        }
    });
});

document.addEventListener('DOMContentLoaded', function() {
    var openReportButton = document.getElementById('openReport');
    openReportButton.addEventListener('click', function() {
        chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
            var activeTab = tabs[0];
            var url = activeTab.url;
            chrome.runtime.sendMessage({action: 'getScore', url: url}, function(response) {
                if (response && response.domain) {
                    var reportUrl = 'https://#конфиденциальный_на_момент_разработки_домен/report/' + response.domain;
                    chrome.tabs.create({ url: reportUrl });
                } else {
                    console.error('Error: Unable to fetch domain from response');
                }
            });
        });
    });
});

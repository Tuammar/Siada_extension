chrome.runtime.onMessage.addListener(function(message, sender, sendResponse) {
    if (message.action === 'getScore') {
        fetch('https://siada.ru/get_score', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ url: message.url })
        })
        .then(response => {
            if (!response.ok) {
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => {
            sendResponse(data);
        })
        .catch(error => {
            console.error('Error:', error);
            sendResponse(null);
        });

        return true;
    }
});

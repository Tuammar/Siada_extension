from crx3 import creator

creator.create_crx_file('background.js', 'manifest.json', 'popup.html', 'popup.js')
